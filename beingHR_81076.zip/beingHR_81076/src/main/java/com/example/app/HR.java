package com.example.app;

import java.util.Iterator;
import java.util.List;

public class HR implements IHRFunctions {
	
	
	public String[] employeeList(String[] listOfEmployees) {
		String sortedEmployeeList[] = new String[listOfEmployees.length];
		//Arrays.sort(sortedEmployeeList); can also be used
		for(int j=0; j<listOfEmployees.length;j++)
		{
			for (int i=j+1 ; i<listOfEmployees.length; i++)
			{
				if(listOfEmployees[i].trim().compareTo(listOfEmployees[j].trim())<0)
				{
					String temp= listOfEmployees[j];
					listOfEmployees[j]= listOfEmployees[i]; 
					listOfEmployees[i]=temp;
				}
			}
		}
		sortedEmployeeList = listOfEmployees;
		return sortedEmployeeList;
	}
 
	public String[] topPerformers(String[] listOfEmployees, List<int[]> parameters) {
		String topPerformers[] = new String[3];
		int[] totalMetrics= new int[5];
 
		Iterator<int[]> listIterator = 	parameters.iterator();
		int loopCount = 0;
		while(listIterator.hasNext()){
			int totalMetricsCount = 0;
			int individualMetrics[] = listIterator.next();
			//Calculating total metrics of the employee
			for(int metrixCount = 0;metrixCount < 5;metrixCount ++){
				totalMetricsCount += individualMetrics[metrixCount];
				System.out.print(totalMetricsCount);
				System.out.print(totalMetricsCount++);
			}
			totalMetrics[loopCount++] = totalMetricsCount;
		}
 
		String topPerformersList[] = sortList1BasedOnList2(listOfEmployees,totalMetrics);
 
		for(int i=0;i<topPerformersList.length;i++)
		System.out.print(topPerformersList[i]+", ");
		//System.out.println(" "+(topPerformersList.length-3));
		//int i = (topPerformersList.length-3);
 
		for(int topPerformer = topPerformersList.length-1,index = 0;topPerformer>=(topPerformersList.length-3);topPerformer--){
			topPerformers[index++] = topPerformersList[topPerformer];
			//System.out.print(topPerformersList[index]+", ");
		}
		return topPerformers;
	}
 
	public String parameterTopper(String[] listOfEmployees, List<int[]> parameters, String parameterType) {
		String parameterTopper = "";
		int parameterIndex = 0;
		for(int index=0;index<App.performanceParameters.length;index++)
			if(App.performanceParameters[index].equals(parameterType)){
				parameterIndex = index;
				break;
			}
		int parameterTopperIndex = 0;
		int topValue = 0,topIndex = 0;
		for(int loopCount = 0;loopCount < listOfEmployees.length;loopCount++){
			if(topValue < parameters.get(loopCount)[parameterIndex]) {
				topValue = parameters.get(loopCount)[parameterIndex];
				topIndex = loopCount;
			}
		}
		parameterTopper = listOfEmployees[topIndex];
 
		return parameterTopper;
	}
 
	public String[] lazyEmployees(String[] listOfEmployees, int[] attendenceList) {
		String lazyEmployeesList[] = new String[5];
		//Calling a new method for required sorting logic
		lazyEmployeesList = sortList1BasedOnList2(listOfEmployees,attendenceList);		
		return lazyEmployeesList;
	}
 
	public String[] sortList1BasedOnList2(String[] listOfEmployees, int[] list2){
		for (int i = 0; i < list2.length; i++) {
        for (int j = i + 1; j < list2.length; j++) {
            int temp = 0;
			String tempString = "";
            if (list2[i] < list2[j]) {
					//Swapping elements of List2
					temp = list2[i];
					list2[i] = list2[j];
					list2[j] = temp;
					//Swapping Names
					tempString = listOfEmployees[i];
					listOfEmployees[i] = listOfEmployees[j];
					listOfEmployees[j] = tempString;
				}
			}
		}
		return listOfEmployees; 
	}

}
